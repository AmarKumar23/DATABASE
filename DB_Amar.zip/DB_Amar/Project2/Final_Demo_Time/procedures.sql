2.Show tables
	1)Students table:
		create or replace procedure show_students(
			s_cursor OUT SYS_REFCURSOR
		)
		is
		begin
			OPEN s_cursor FOR
			select * from students;
		end show_students;
	2)Courses tabel:
		create or replace procedure show_courses(
		s_cursor OUT SYS_REFCURSOR
		)
		is
		begin
			OPEN s_cursor FOR
			select * from courses;
		end show_courses;
	3)Classes table
		create or replace procedure show_classes(
		s_cursor OUT SYS_REFCURSOR
		)
		is
		begin
			OPEN s_cursor FOR
			select * from classes;
		end show_classes;
	4)Enrollments table
		create or replace procedure show_enrollments(
			s_cursor OUT SYS_REFCURSOR
		)
		is
		begin
			OPEN s_cursor FOR
			select * from enrollments;
		end show_enrollments;	
	5)Logs table
		create or replace procedure show_logs(
			s_cursor OUT SYS_REFCURSOR
		)
		is
		begin
			OPEN s_cursor FOR
			select * from logs;
		end show_logs;	
	6)Prerequisite table
		create or replace procedure show_prerequisites(
			s_cursor OUT SYS_REFCURSOR
		)
		is
		begin
			OPEN s_cursor FOR
			select * from prerequisites;
		end show_prerequisites;
3)Add student
		create or replace procedure add_students (p_sid in char,p_firstname in varchar2,p_lastname in varchar2,p_status in varchar2,
			p_gpa in number,p_email in varchar2,results out varchar)
		is
		v_sid students.sid%type;
		v_firstname students.firstname%type;
		v_lastname students.lastname%type;
		v_status students.status%type;
		v_gpa students.gpa%type;
		v_email students.email%type;

		begin
		v_sid:=p_sid;
		v_firstname:=p_firstname;
		v_lastname:=p_lastname;
		v_status:=p_status;
		v_gpa:=p_gpa;
		v_email:=p_email;

		IF NOT(REGEXP_LIKE(v_sid,'^B[0-9][0-9][0-9]$')) THEN
		 results:='Sid should be of the from B[0-9][0-9][0-9]';
		ELSIF NOT(REGEXP_LIKE(v_status,'freshman|sophomore|senior|graduate|junior')) THEN
		results:='Status should be any one of these - freshman|sophomore|senior|graduate|junior';
		ELSIF  NOT((v_gpa >=0 and v_gpa <=4.0)) THEN
		 results:='gpa values should be in the range of 0 to 4.0';
		ELSE

		insert into students values(v_sid,v_firstname,v_lastname,v_status,v_gpa,v_email);

		commit;
		results := 'New student record is inserted.';
			END IF;
		EXCEPTION
		WHEN DUP_VAL_ON_INDEX THEN
			results:='Trying to insert duplicate student record.Either sid OR email already exists';
		WHEN OTHERS THEN
			results := 'SQL Error: ' || ' SQLCODE=' || SQLCODE || '. SQLERRM=' || SQLERRM;

		end add_students;	
4)
		create or replace procedure student_detail(p_sid in char,results out clob)
		is
		v_sid students.sid%type;
		t_sid students.sid%type;
		v_lastname students.lastname%type;
		v_status students.status%type;
		v_classid classes.classid%type;
		v_course varchar2(10);
		v_title courses.title%type;
		v_year classes.year%type;
		v_semester classes.semester%type;
		res clob;

		begin
		v_sid:=p_sid;
		v_classid:='00000';
		for i in
		(
			select s.sid,s.lastname,s.status,cl.classid,cl.dept_code || cl.course_no course,c.title,cl.year,cl.semester
		from students s join enrollments e on 
		s.sid=e.sid 
		join classes cl on 
		e.classid=cl.classid
		join courses c on
		cl.dept_code || cl.course_no =c.dept_code || c.course_no 
		where s.sid=v_sid
		)
		loop
			
		v_sid:=i.sid;
		v_lastname:=i.lastname;
		v_status:=i.status;
		v_classid:=i.classid;
		v_course:=i.course;
		v_title:=i.title;
		v_year:=i.year;
		v_semester:=i.semester;

		res:=v_sid || '  ' || v_lastname || '  ' || v_status || '  ' || v_classid || '  ' || v_course || '  ' || v_title || '  ' || v_year || '  ' || v_semester;
		results:=concat(concat(results,'    '),res);
		end loop;


		select sid into t_sid from students where sid=v_sid;
		v_classid:=null;

		select cl.classid into v_classid from students s join enrollments e on
		s.sid=e.sid 
		join classes cl on
		e.classid=cl.classid
		where s.sid=v_sid
		and rownum=1;

		exception when no_data_found
		then 
		if  t_sid is null
		then
		results:='The Student Id is invalid';
		end if;

		if v_classid is null
		then 
		results:='The Student has not taken any course';
		end if;

		end student_detail;
5)
		create or replace procedure pre_req_courses(p_dept_code in varchar2,p_course_no in number,results out clob)
		is
		v_dept_code prerequisites.dept_code%type;
		v_course_no prerequisites.course_no%type;
		v_course varchar2(10);
		res clob;
		begin
		v_dept_code:=p_dept_code;
		v_course_no:=p_course_no;
		v_course:=v_dept_code||v_course_no;
		for i in
		(
		select pre_dept_code || pre_course_no pre_req_courses
		from prerequisites 
		start with course_no=v_course_no
		connect by course_no = prior pre_course_no
		)
		loop
			 
		res:=v_course || '   ' || i.pre_req_courses;
		results:=concat(concat(results,'    '),res);
		end loop;

		end pre_req_courses;
6)
		create or replace procedure class_details(p_class_id in char,results out clob)
		is
		v_class_id classes.classid%type;
		v_title courses.title%type;
		v_semester classes.semester%type;
		v_year classes.year%type;
		v_sid students.sid%type;
		v_lastname students.lastname%type;
		t_class_id classes.classid%type;
		t_sid students.sid%type;
		res clob;

		begin
		v_class_id:=p_class_id;
		t_sid:='0000';


		for i in
		(
		select cl.classid,c.title,cl.semester,cl.year,s.sid,s.lastname 
		from classes cl join courses c
		on cl.dept_code=c.dept_code and
		cl.course_no=c.course_no 
		join enrollments e
		on cl.classid=e.classid 
		join students s
		on s.sid=e.sid
		where cl.classid=v_class_id
		   
		)
		loop
		v_class_id:=i.classid;
		v_title:=i.title;
		v_semester:=i.semester;
		v_year:=i.year;
		v_sid:=i.sid;  
		v_lastname:=i.lastname;

		res:=v_class_id || '  ' || v_title || '  ' || v_semester || '  ' || v_year || '  ' || v_sid || '  ' || v_lastname;
		results:=concat(concat(results,'   '),res);
		end loop;


		select distinct classid into t_class_id from classes where classid=v_class_id;
		dbms_output.put_line(res);

		t_sid:=null;

		select s.sid into t_sid
		from classes cl join courses c
		on cl.dept_code=c.dept_code and
		cl.course_no=c.course_no 
		join enrollments e
		on cl.classid=e.classid 
		join students s
		on s.sid=e.sid
		where cl.classid=v_class_id
		and rownum=1;

		exception when no_data_found
		then 
		if t_class_id is null
		then 
		results:='The Class Id is invalid';
		end if;

		if t_sid is null
		then 
		results:='No students has enrolled in this class';
		end if;
		end class_details;
7)
		create or replace procedure student_enrollment(p_class_id in char,p_sid in char, results out varchar)
is
v_sid students.sid%type;
v_class_id classes.classid%type;
t_sid students.sid%type;
t_class_id classes.classid%type;
v_class_size classes.class_size%type;
v_limit classes.limit%type;
v_year classes.year%type;
v_semester classes.semester%type;
v_tot_classes number(1);
v_check number(1);
v_lgrade enrollments.lgrade%type;
begin
    v_sid:=p_sid;
v_class_id:=p_class_id;
t_class_id:='00000';
v_check:=0;
v_tot_classes:=0;
select sid into t_sid from students where sid=v_sid;

t_class_id:=null;

select classid into t_class_id from classes where classid=v_class_id;

select class_size,limit into v_class_size,v_limit 
from classes where classid=v_class_id;

select count(e.sid) into v_check from classes cl join enrollments e 
on cl.classid=e.classid where e.sid=v_sid and e.classid=v_class_id;


if(v_check=1)
then 
dbms_output.put_line('The Student is already in the Class');
end if;


--if((v_class_size + 1)>v_limit and (v_check=0))
--then 
--dbms_output.put_line('The Class is closed');
--end if;


select year,semester into v_year,v_semester
from classes where classid=v_class_id;


if v_check > 0 then
    select count(cl.classid) into v_tot_classes
    from classes cl join enrollments e on
    cl.classid=e.classid
    where e.sid=v_sid 
    and cl.year=v_year
    and cl.semester=v_semester
    group by cl.year,cl.semester;
end if;

if (v_tot_classes=2 and v_check=0)
then 
insert into enrollments values(v_sid,v_class_id,null);
commit;

results:='You are overloaded';
results:='Successfully Enrolled';
end if;




if (v_tot_classes<=2 and v_check=0)
then
insert into enrollments values(v_sid,v_class_id,null);
commit;
results:='Successfully Enrolled';
end if;

if(v_tot_classes=3)
then 
results:='Student cannot be enrolled in more than 3 classes in the same semester'; 
end if;

for i in
(
select lgrade from enrollments where classid in
(
select classid from classes where course_no in (select course_no pre_req_courses
from prerequisites 
start with course_no= (select course_no from classes where classid=v_class_id)
connect by course_no = prior pre_course_no))
and sid=v_sid
)
loop
v_lgrade:=i.lgrade;
if (v_lgrade>'D')
then
results:='Prerequisite Courses have not been completed';
exit;
end if;
end loop;


exception when no_data_found
then
if t_sid is null 
then
results:='The Student Id is invalid';
end if;

if t_class_id is null
then
results:='The Class Id is invalid';
end if;
when dup_val_on_index
then
results:='Class is full';
end student_enrollment;​

8)
		create or replace procedure remove_enrollment(p_class_id in char,p_sid in char,results out clob)
		is
		v_sid students.sid%type;
		v_class_id classes.classid%type;
		t_sid students.sid%type;
		t_class_id classes.classid%type;
		v_check number(1);
		v_pre_course_check number(1);
		v_stu_class_cnt_check number(1);
		v_class_enroll_check number(2);
		begin
		v_sid:=p_sid;
		v_class_id:=p_class_id;
		t_class_id:='00000';
		v_check:=1;
		v_pre_course_check:=0;

		select sid into t_sid from students where sid=v_sid;

		t_class_id:=null;

		select classid into t_class_id from classes where classid=v_class_id;

		select count(e.sid) into v_check from classes cl join enrollments e 
		on cl.classid=e.classid where e.sid=v_sid and e.classid=v_class_id;

		select count(pre_course_no) into v_pre_course_check
		from prerequisites 
		start with course_no=(select course_no from classes where classid=v_class_id)
		connect by prior course_no = pre_course_no;

		if(v_check=0)
		then
		results:='The Student is not enrolled in the class';

		elsif(v_pre_course_check > 0)
		then
		results:='The drop is not permitted because another class uses it as a prerequisite';

		else
		delete from enrollments where sid=v_sid and classid=v_class_id;
		results:='The Student is unenrolled';

		select count(classid) into v_stu_class_cnt_check from enrollments where sid=v_sid;

		if(v_stu_class_cnt_check=0)
		then
		results:='This student is not enrolled in any classes';
		end if;

		select count(sid) into v_class_enroll_check  from enrollments where classid=v_class_id;

		if(v_class_enroll_check=0)
		then
		results:='The class now has no students';
		end if;
		end if;

		exception when no_data_found
		then
		if t_sid is null 
		then 
		results:='The Student Id is invalid';
		end if;

		if t_class_id is null
		then
		results:='The Class Id is invalid';
		end if;
		end remove_enrollment;
9)
		create or replace procedure student_delete(p_sid in varchar2,results out varchar)
		is
		v_sid students.sid%type;
		t_sid students.sid%type;
		begin
		v_sid:=p_sid;

		select sid into t_sid from students where sid=v_sid;

		delete from students where sid=v_sid;
		results:= 'The Student Record is Deleted.';
		commit;

		exception when no_data_found
		then
		if t_sid is null 
		then
		results:='The Student Id is invalid';
		end if;

		end student_delete;